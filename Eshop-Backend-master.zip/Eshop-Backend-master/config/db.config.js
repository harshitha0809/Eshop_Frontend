module.exports = {
  url: "mongodb+srv://Mufeeth:mufeeth@movieappcluster.rdkf9.mongodb.net/Eshop?retryWrites=true&w=majority",
};
